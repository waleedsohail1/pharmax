# Change Log

## [1.1.0] 2018-05-04
### Bootstrap 4.1.0 update
- Archive cleaned
- Other small bug fixes

## [1.0.1] 2018-02-21
### Bugfixing
- Fixed some issues for documentation pages
- Scss cleaned
- Other bug fixes

## [1.0.0] 2018-02-14
### Original Release
